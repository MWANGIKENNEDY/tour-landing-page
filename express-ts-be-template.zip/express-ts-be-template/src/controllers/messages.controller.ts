import { Request, Response } from "express";
import prisma from "../../prisma/client";



/**
 * Create a message in a chat.
 * If chat does not exist, it will create a new one with provided members.
 */
export const createMessage = async (req: Request, res: Response) => {
  try {
    const { chatId, memberIds, content } = req.body;
    
    if (!req.auth?.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    const senderId = req.auth.userId;

    if (!content || !content.trim()) {
      return res.status(400).json({ message: "Message content is required" });
    }

    let chat = null;

    // 1️⃣ If chatId is provided → fetch the chat
    if (chatId) {
      chat = await prisma.chat.findUnique({
        where: { id: chatId },
        include: { members: true }
      });
    }

    // 2️⃣ If chat doesn't exist → create a new chat with members
    if (!chat) {
      if (!memberIds || memberIds.length === 0) {
        return res.status(400).json({ message: "Member IDs are required to create a new chat" });
      }

      // Include sender automatically
      const allMembers = Array.from(new Set([senderId, ...memberIds]));

      chat = await prisma.chat.create({
        data: {
          members: {
            create: allMembers.map((id) => ({ userId: id }))
          }
        },
        include: { members: true }
      });
    }

    // 3️⃣ Save the message
    const message = await prisma.message.create({
      data: {
        chatId: chat.id,
        senderId,
        content
      },
      include: {
        sender: true
      }
    });

    res.status(201).json({
      chatId: chat.id,
      message
    });
  } catch (error) {
    console.error("createMessage error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/**
 * Get messages for a chat
 */
export const getMessages = async (req: Request, res: Response) => {
  try {
    const { chatId } = req.params;

    if (!chatId) return res.status(400).json({ message: "chatId is required" });

    const messages = await prisma.message.findMany({
      where: { chatId },
      orderBy: { createdAt: "asc" },
      include: { sender: true }
    });

    res.json(messages);
  } catch (error) {
    console.error("getMessages error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
