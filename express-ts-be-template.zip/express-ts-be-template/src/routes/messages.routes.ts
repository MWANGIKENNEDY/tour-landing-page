import { Router } from "express";
import { createMessage, getMessages } from "../controllers/messages.controller";
import { mockAuth } from "../middleware/auth.middleware";

const router = Router();

// Apply mock authentication to all message routes
router.use(mockAuth);

/**
 * POST /api/messages
 * Body: { chatId?, memberIds?, content }
 * - Creates a message
 * - Auto-creates chat if needed
 */
router.post("/", createMessage);

/**
 * GET /api/messages/:chatId
 * - Get all messages in a chat
 */
router.get("/:chatId", getMessages);

export default router;


