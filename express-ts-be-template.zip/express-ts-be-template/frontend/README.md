# Chat Application

A full-stack chat application with Express TypeScript backend and Next.js frontend.

## Architecture Overview

```
Frontend (Next.js)  ←→  Backend (Express)  ←→  Database (PostgreSQL)
     Port 3000              Port 4000              Neon Cloud
```

## How It Works

### Backend API Structure

The Express backend provides two main endpoints:

#### 1. POST /api/messages - Send Message
**Purpose**: Create a new message and optionally create a new chat

**Request Headers**:
```
x-user-id: <user-uuid>     // Identifies the sender
Content-Type: application/json
```

**Request Body**:
```json
{
  "content": "Hello world!",           // Required: message text
  "chatId": "existing-chat-uuid",     // Optional: existing chat ID
  "memberIds": ["user1", "user2"]     // Required if no chatId: users to include
}
```

**Backend Flow**:
1. Auth middleware sets `req.auth.userId` from `x-user-id` header
2. Controller validates message content exists
3. If `chatId` provided → fetch existing chat
4. If no chat exists → create new chat with provided `memberIds`
5. Create message record linked to chat and sender
6. Return chat ID and message data

**Response**:
```json
{
  "chatId": "chat-uuid",
  "message": {
    "id": "message-uuid",
    "content": "Hello world!",
    "createdAt": "2024-01-06T14:30:00Z",
    "sender": {
      "id": "user-uuid",
      "name": "Alice Johnson"
    }
  }
}
```

#### 2. GET /api/messages/:chatId - Get Messages
**Purpose**: Retrieve all messages for a specific chat

**Request**: 
```
GET /api/messages/550e8400-e29b-41d4-a716-446655440000
```

**Backend Flow**:
1. Extract `chatId` from URL parameters
2. Query database for all messages in that chat
3. Include sender information via Prisma relations
4. Order messages by creation time (oldest first)

**Response**:
```json
[
  {
    "id": "msg-1",
    "content": "First message",
    "createdAt": "2024-01-06T14:30:00Z",
    "sender": { "id": "user1", "name": "Alice Johnson" }
  },
  {
    "id": "msg-2", 
    "content": "Second message",
    "createdAt": "2024-01-06T14:31:00Z",
    "sender": { "id": "user2", "name": "Bob Smith" }
  }
]
```

### Frontend-Backend Communication

#### Sending Messages Flow

1. **User types message** in frontend input field
2. **Frontend prepares request**:
   ```typescript
   const payload = {
     content: newMessage.trim(),
     chatId: existingChatId || undefined,
     memberIds: existingChatId ? undefined : otherUserIds
   }
   ```

3. **HTTP Request sent**:
   ```typescript
   const response = await axios.post(`${API_BASE}/messages`, payload, {
     headers: {
       'x-user-id': currentUser.id,
       'Content-Type': 'application/json'
     }
   })
   ```

4. **Backend processes**:
   - Auth middleware identifies sender
   - Controller creates/finds chat
   - Message saved to PostgreSQL
   - Response sent back

5. **Frontend handles response**:
   - Saves `chatId` for future messages
   - Clears input field
   - Refreshes message list

#### Loading Messages Flow

1. **Frontend needs to display messages** (on load or after sending)
2. **HTTP Request sent**:
   ```typescript
   const response = await axios.get(`${API_BASE}/messages/${chatId}`)
   ```

3. **Backend queries database**:
   ```sql
   SELECT m.*, u.name as sender_name 
   FROM Message m 
   JOIN User u ON m.senderId = u.id 
   WHERE m.chatId = ? 
   ORDER BY m.createdAt ASC
   ```

4. **Frontend renders messages**:
   - Maps over message array
   - Shows sender name and timestamp
   - Applies different styling for sent vs received

### Database Schema

```sql
User {
  id        String   @id @default(uuid())
  name      String
  createdAt DateTime @default(now())
}

Chat {
  id        String   @id @default(uuid()) 
  createdAt DateTime @default(now())
}

ChatMember {
  id     String @id @default(uuid())
  userId String  // Foreign key to User
  chatId String  // Foreign key to Chat
  
  @@unique([userId, chatId])  // User can only be in chat once
}

Message {
  id        String   @id @default(uuid())
  chatId    String   // Foreign key to Chat
  senderId  String   // Foreign key to User  
  content   String
  createdAt DateTime @default(now())
  
  @@index([chatId, createdAt])  // Optimize message queries
}
```

### State Management & Persistence

#### Frontend State
- `currentUser`: Currently selected user (Alice, Bob, etc.)
- `chatId`: Current active chat ID
- `messages`: Array of messages in current chat
- `newMessage`: Text input value

#### Persistence Strategy
1. **localStorage**: Saves `chatId` to survive page refreshes
2. **Database**: All messages and chats permanently stored in PostgreSQL
3. **Auto-reload**: On page load, checks localStorage for `chatId` and loads messages

#### User Switching
- Users can switch perspectives without losing chat context
- Same chat viewed from different user accounts
- Messages show as "sent" or "received" based on current user

## Setup Instructions

### Backend Setup
1. Install dependencies: `npm install`
2. Set up PostgreSQL database (Neon)
3. Configure `.env` with `DATABASE_URL`
4. Run migrations: `npx prisma migrate dev`
5. Seed users: `npx prisma db seed`
6. Start server: `npm run dev` (port 4000)

### Frontend Setup
1. Navigate to frontend: `cd frontend`
2. Install dependencies: `npm install`
3. Start development: `npm run dev` (port 3000)
4. Open browser: `http://localhost:3000`

## Usage Flow

1. **Select User**: Choose Alice, Bob, Charlie, or Diana
2. **Send Message**: Type and press Enter or click Send
3. **Auto-Chat Creation**: First message creates chat with all other users
4. **Switch Perspectives**: Change users to see different viewpoints
5. **Persistent History**: Refresh page - messages remain loaded
6. **New Chat**: Click red "New Chat" button to start fresh

## Error Handling

- **Authentication**: Missing `x-user-id` returns 401
- **Validation**: Empty messages return 400
- **Database**: Foreign key violations handled gracefully
- **Network**: Frontend shows error messages for failed requests
- **Loading States**: UI shows loading indicators during requests

## Security Notes

- Uses mock authentication (development only)
- User ID passed via header (replace with JWT in production)
- No input sanitization (add validation in production)
- CORS enabled for localhost development