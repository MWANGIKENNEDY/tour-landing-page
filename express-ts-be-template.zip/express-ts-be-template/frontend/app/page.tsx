'use client'

import { useState, useEffect } from 'react'
import axios from 'axios'

const API_BASE = 'http://localhost:4000/api'

interface User {
  id: string
  name: string
}

interface Message {
  id: string
  content: string
  createdAt: string
  sender: User
  chatId: string
}

interface Chat {
  id: string
  createdAt: string
}

const users: User[] = [
  { id: 'ccc76fd6-ac64-4b00-995c-caab31a90496', name: 'Alice Johnson' },
  { id: '2d759dd8-05e7-4e0e-bb2b-f87d0e5a5300', name: 'Bob Smith' },
  { id: 'ee07eb77-0b00-4bb0-bfe5-a6837bb3cf1c', name: 'Charlie Brown' },
  { id: 'c47380c0-8579-4273-94de-c9ee0001afc4', name: 'Diana Prince' },
]

export default function ChatApp() {
  const [currentUser, setCurrentUser] = useState<User>(users[0])
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [chatId, setChatId] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Load chatId from localStorage on component mount
  useEffect(() => {
    const savedChatId = localStorage.getItem('currentChatId')
    if (savedChatId) {
      setChatId(savedChatId)
      loadMessages(savedChatId)
    }
  }, [])

  // Save chatId to localStorage whenever it changes
  useEffect(() => {
    if (chatId) {
      localStorage.setItem('currentChatId', chatId)
    }
  }, [chatId])

  const sendMessage = async () => {
    if (!newMessage.trim()) return

    setLoading(true)
    setError(null)

    try {
      const payload: any = {
        content: newMessage.trim()
      }

      // If we have a chatId, use it. Otherwise, create new chat with other users
      if (chatId) {
        payload.chatId = chatId
      } else {
        // Include other users as members for new chat
        payload.memberIds = users
          .filter(user => user.id !== currentUser.id)
          .map(user => user.id)
      }

      const response = await axios.post(`${API_BASE}/messages`, payload, {
        headers: {
          'x-user-id': currentUser.id,
          'Content-Type': 'application/json'
        }
      })

      // Set chatId if this was a new chat
      if (!chatId && response.data.chatId) {
        setChatId(response.data.chatId)
      }

      setNewMessage('')
      
      // Refresh messages
      if (response.data.chatId) {
        loadMessages(response.data.chatId)
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to send message')
    } finally {
      setLoading(false)
    }
  }

  const loadMessages = async (chatIdToLoad: string) => {
    try {
      const response = await axios.get(`${API_BASE}/messages/${chatIdToLoad}`)
      setMessages(response.data)
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to load messages')
    }
  }

  const switchUser = (user: User) => {
    setCurrentUser(user)
    // Don't clear messages and chatId when switching users
    // This allows users to see the same chat from different perspectives
  }

  const startNewChat = () => {
    setMessages([])
    setChatId(null)
    setError(null)
    localStorage.removeItem('currentChatId')
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  return (
    <div className="container">
      <h1 style={{ textAlign: 'center', marginBottom: '30px', color: '#374151' }}>
        Chat Application
      </h1>

      {error && (
        <div className="error">
          {error}
        </div>
      )}

      <div className="user-selector">
        <h3>Select User:</h3>
        <div className="user-buttons">
          {users.map(user => (
            <button
              key={user.id}
              className={`user-button ${currentUser.id === user.id ? 'active' : ''}`}
              onClick={() => switchUser(user)}
            >
              {user.name}
            </button>
          ))}
          <button
            className="user-button"
            onClick={startNewChat}
            style={{ background: '#ef4444', color: 'white', border: '2px solid #ef4444' }}
          >
            New Chat
          </button>
        </div>
      </div>

      <div className="chat-container">
        <div className="chat-header">
          <h2>Chat as {currentUser.name}</h2>
          {chatId && <p style={{ opacity: 0.8, fontSize: '14px' }}>Chat ID: {chatId}</p>}
        </div>

        <div className="messages-container">
          {messages.length === 0 ? (
            <div className="loading">
              {chatId ? 'No messages yet. Start the conversation!' : 'Send a message to start a new chat!'}
            </div>
          ) : (
            messages.map(message => (
              <div
                key={message.id}
                className={`message ${message.sender.id === currentUser.id ? 'sent' : 'received'}`}
              >
                <div>{message.content}</div>
                <div className="message-info">
                  {message.sender.name} • {new Date(message.createdAt).toLocaleTimeString()}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="input-container">
          <input
            type="text"
            className="message-input"
            placeholder="Type your message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={loading}
          />
          <button
            className="send-button"
            onClick={sendMessage}
            disabled={loading || !newMessage.trim()}
          >
            {loading ? 'Sending...' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  )
}