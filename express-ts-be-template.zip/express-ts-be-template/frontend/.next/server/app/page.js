/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/page";
exports.ids = ["app/page"];
exports.modules = {

/***/ "../../client/components/action-async-storage.external":
/*!*******************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external.js" ***!
  \*******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/action-async-storage.external.js");

/***/ }),

/***/ "./request-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/request-async-storage.external");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!********************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external.js" ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/request-async-storage.external.js");

/***/ }),

/***/ "./static-generation-async-storage.external":
/*!***************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external" ***!
  \***************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/static-generation-async-storage.external");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!******************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external.js" ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/static-generation-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "http2":
/*!************************!*\
  !*** external "http2" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("http2");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fpage&page=%2Fpage&appPaths=%2Fpage&pagePath=private-next-app-dir%2Fpage.tsx&appDir=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fpage&page=%2Fpage&appPaths=%2Fpage&pagePath=private-next-app-dir%2Fpage.tsx&appDir=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),\n/* harmony export */   __next_app__: () => (/* binding */ __next_app__),\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   pages: () => (/* binding */ pages),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   tree: () => (/* binding */ tree)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-page/module.compiled */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/module.compiled.js?5bc9\");\n/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/client/components/error-boundary */ \"(rsc)/./node_modules/next/dist/client/components/error-boundary.js\");\n/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/dist/server/app-render/entry-base */ \"(rsc)/./node_modules/next/dist/server/app-render/entry-base.js\");\n/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};\n/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if([\"default\",\"tree\",\"pages\",\"GlobalError\",\"originalPathname\",\"__next_app__\",\"routeModule\"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]\n/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);\n\"TURBOPACK { transition: next-ssr }\";\n\n\n// We inject the tree and pages here so that we can use them in the route\n// module.\nconst tree = {\n        children: [\n        '',\n        {\n        children: ['__PAGE__', {}, {\n          page: [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/page.tsx */ \"(rsc)/./app/page.tsx\")), \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\"],\n          \n        }]\n      },\n        {\n        'layout': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/layout.tsx */ \"(rsc)/./app/layout.tsx\")), \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/layout.tsx\"],\n'not-found': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! next/dist/client/components/not-found-error */ \"(rsc)/./node_modules/next/dist/client/components/not-found-error.js\", 23)), \"next/dist/client/components/not-found-error\"],\n        \n      }\n      ]\n      }.children;\nconst pages = [\"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\"];\n\n\nconst __next_app_require__ = __webpack_require__\nconst __next_app_load_chunk__ = () => Promise.resolve()\nconst originalPathname = \"/page\";\nconst __next_app__ = {\n    require: __next_app_require__,\n    loadChunk: __next_app_load_chunk__\n};\n\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,\n        page: \"/page\",\n        pathname: \"/\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\",\n        appPaths: []\n    },\n    userland: {\n        loaderTree: tree\n    }\n});\n\n//# sourceMappingURL=app-page.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZwYWdlJnBhZ2U9JTJGcGFnZSZhcHBQYXRocz0lMkZwYWdlJnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGcGFnZS50c3gmYXBwRGlyPSUyRlVzZXJzJTJGa2tpaXJ1JTJGRGVza3RvcCUyRmV4cHJlc3MtdHMtYmUtdGVtcGxhdGUlMkZmcm9udGVuZCUyRmFwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9JTJGVXNlcnMlMkZra2lpcnUlMkZEZXNrdG9wJTJGZXhwcmVzcy10cy1iZS10ZW1wbGF0ZSUyRmZyb250ZW5kJmlzRGV2PXRydWUmdHNjb25maWdQYXRoPXRzY29uZmlnLmpzb24mYmFzZVBhdGg9JmFzc2V0UHJlZml4PSZuZXh0Q29uZmlnT3V0cHV0PSZwcmVmZXJyZWRSZWdpb249Jm1pZGRsZXdhcmVDb25maWc9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsYUFBYSxzQkFBc0I7QUFDaUU7QUFDckM7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDLHVCQUF1Qix3SUFBdUc7QUFDOUg7QUFDQSxTQUFTO0FBQ1QsT0FBTztBQUNQO0FBQ0EseUJBQXlCLDRJQUF5RztBQUNsSSxvQkFBb0IsME5BQWdGO0FBQ3BHO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUN1QjtBQUM2RDtBQUNwRiw2QkFBNkIsbUJBQW1CO0FBQ2hEO0FBQ087QUFDQTtBQUNQO0FBQ0E7QUFDQTtBQUN1RDtBQUN2RDtBQUNPLHdCQUF3Qiw4R0FBa0I7QUFDakQ7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2hhdC1mcm9udGVuZC8/YzhkNyJdLCJzb3VyY2VzQ29udGVudCI6WyJcIlRVUkJPUEFDSyB7IHRyYW5zaXRpb246IG5leHQtc3NyIH1cIjtcbmltcG9ydCB7IEFwcFBhZ2VSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL2FwcC1wYWdlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbi8vIFdlIGluamVjdCB0aGUgdHJlZSBhbmQgcGFnZXMgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IHRyZWUgPSB7XG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICcnLFxuICAgICAgICB7XG4gICAgICAgIGNoaWxkcmVuOiBbJ19fUEFHRV9fJywge30sIHtcbiAgICAgICAgICBwYWdlOiBbKCkgPT4gaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCIvVXNlcnMva2tpaXJ1L0Rlc2t0b3AvZXhwcmVzcy10cy1iZS10ZW1wbGF0ZS9mcm9udGVuZC9hcHAvcGFnZS50c3hcIiksIFwiL1VzZXJzL2traWlydS9EZXNrdG9wL2V4cHJlc3MtdHMtYmUtdGVtcGxhdGUvZnJvbnRlbmQvYXBwL3BhZ2UudHN4XCJdLFxuICAgICAgICAgIFxuICAgICAgICB9XVxuICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAnbGF5b3V0JzogWygpID0+IGltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL1VzZXJzL2traWlydS9EZXNrdG9wL2V4cHJlc3MtdHMtYmUtdGVtcGxhdGUvZnJvbnRlbmQvYXBwL2xheW91dC50c3hcIiksIFwiL1VzZXJzL2traWlydS9EZXNrdG9wL2V4cHJlc3MtdHMtYmUtdGVtcGxhdGUvZnJvbnRlbmQvYXBwL2xheW91dC50c3hcIl0sXG4nbm90LWZvdW5kJzogWygpID0+IGltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwibmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL25vdC1mb3VuZC1lcnJvclwiKSwgXCJuZXh0L2Rpc3QvY2xpZW50L2NvbXBvbmVudHMvbm90LWZvdW5kLWVycm9yXCJdLFxuICAgICAgICBcbiAgICAgIH1cbiAgICAgIF1cbiAgICAgIH0uY2hpbGRyZW47XG5jb25zdCBwYWdlcyA9IFtcIi9Vc2Vycy9ra2lpcnUvRGVza3RvcC9leHByZXNzLXRzLWJlLXRlbXBsYXRlL2Zyb250ZW5kL2FwcC9wYWdlLnRzeFwiXTtcbmV4cG9ydCB7IHRyZWUsIHBhZ2VzIH07XG5leHBvcnQgeyBkZWZhdWx0IGFzIEdsb2JhbEVycm9yIH0gZnJvbSBcIm5leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9lcnJvci1ib3VuZGFyeVwiO1xuY29uc3QgX19uZXh0X2FwcF9yZXF1aXJlX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fXG5jb25zdCBfX25leHRfYXBwX2xvYWRfY2h1bmtfXyA9ICgpID0+IFByb21pc2UucmVzb2x2ZSgpXG5leHBvcnQgY29uc3Qgb3JpZ2luYWxQYXRobmFtZSA9IFwiL3BhZ2VcIjtcbmV4cG9ydCBjb25zdCBfX25leHRfYXBwX18gPSB7XG4gICAgcmVxdWlyZTogX19uZXh0X2FwcF9yZXF1aXJlX18sXG4gICAgbG9hZENodW5rOiBfX25leHRfYXBwX2xvYWRfY2h1bmtfX1xufTtcbmV4cG9ydCAqIGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2FwcC1yZW5kZXIvZW50cnktYmFzZVwiO1xuLy8gQ3JlYXRlIGFuZCBleHBvcnQgdGhlIHJvdXRlIG1vZHVsZSB0aGF0IHdpbGwgYmUgY29uc3VtZWQuXG5leHBvcnQgY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUGFnZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUEFHRSxcbiAgICAgICAgcGFnZTogXCIvcGFnZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvXCIsXG4gICAgICAgIC8vIFRoZSBmb2xsb3dpbmcgYXJlbid0IHVzZWQgaW4gcHJvZHVjdGlvbi5cbiAgICAgICAgYnVuZGxlUGF0aDogXCJcIixcbiAgICAgICAgZmlsZW5hbWU6IFwiXCIsXG4gICAgICAgIGFwcFBhdGhzOiBbXVxuICAgIH0sXG4gICAgdXNlcmxhbmQ6IHtcbiAgICAgICAgbG9hZGVyVHJlZTogdHJlZVxuICAgIH1cbn0pO1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcGFnZS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fpage&page=%2Fpage&appPaths=%2Fpage&pagePath=private-next-app-dir%2Fpage.tsx&appDir=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp%2Fglobals.css&server=true!":
/*!**************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp%2Fglobals.css&server=true! ***!
  \**************************************************************************************************************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp%2Fpage.tsx&server=true!":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp%2Fpage.tsx&server=true! ***!
  \***********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

eval("Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/page.tsx */ \"(ssr)/./app/page.tsx\"))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWZsaWdodC1jbGllbnQtZW50cnktbG9hZGVyLmpzP21vZHVsZXM9JTJGVXNlcnMlMkZra2lpcnUlMkZEZXNrdG9wJTJGZXhwcmVzcy10cy1iZS10ZW1wbGF0ZSUyRmZyb250ZW5kJTJGYXBwJTJGcGFnZS50c3gmc2VydmVyPXRydWUhIiwibWFwcGluZ3MiOiJBQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2hhdC1mcm9udGVuZC8/ZTA0MSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9Vc2Vycy9ra2lpcnUvRGVza3RvcC9leHByZXNzLXRzLWJlLXRlbXBsYXRlL2Zyb250ZW5kL2FwcC9wYWdlLnRzeFwiKSJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp%2Fpage.tsx&server=true!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true!":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true! ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

eval("Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/app-router.js */ \"(ssr)/./node_modules/next/dist/client/components/app-router.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/error-boundary.js */ \"(ssr)/./node_modules/next/dist/client/components/error-boundary.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/layout-router.js */ \"(ssr)/./node_modules/next/dist/client/components/layout-router.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/not-found-boundary.js */ \"(ssr)/./node_modules/next/dist/client/components/not-found-boundary.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/render-from-template-context.js */ \"(ssr)/./node_modules/next/dist/client/components/render-from-template-context.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js */ \"(ssr)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js\", 23))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWZsaWdodC1jbGllbnQtZW50cnktbG9hZGVyLmpzP21vZHVsZXM9JTJGVXNlcnMlMkZra2lpcnUlMkZEZXNrdG9wJTJGZXhwcmVzcy10cy1iZS10ZW1wbGF0ZSUyRmZyb250ZW5kJTJGbm9kZV9tb2R1bGVzJTJGbmV4dCUyRmRpc3QlMkZjbGllbnQlMkZjb21wb25lbnRzJTJGYXBwLXJvdXRlci5qcyZtb2R1bGVzPSUyRlVzZXJzJTJGa2tpaXJ1JTJGRGVza3RvcCUyRmV4cHJlc3MtdHMtYmUtdGVtcGxhdGUlMkZmcm9udGVuZCUyRm5vZGVfbW9kdWxlcyUyRm5leHQlMkZkaXN0JTJGY2xpZW50JTJGY29tcG9uZW50cyUyRmVycm9yLWJvdW5kYXJ5LmpzJm1vZHVsZXM9JTJGVXNlcnMlMkZra2lpcnUlMkZEZXNrdG9wJTJGZXhwcmVzcy10cy1iZS10ZW1wbGF0ZSUyRmZyb250ZW5kJTJGbm9kZV9tb2R1bGVzJTJGbmV4dCUyRmRpc3QlMkZjbGllbnQlMkZjb21wb25lbnRzJTJGbGF5b3V0LXJvdXRlci5qcyZtb2R1bGVzPSUyRlVzZXJzJTJGa2tpaXJ1JTJGRGVza3RvcCUyRmV4cHJlc3MtdHMtYmUtdGVtcGxhdGUlMkZmcm9udGVuZCUyRm5vZGVfbW9kdWxlcyUyRm5leHQlMkZkaXN0JTJGY2xpZW50JTJGY29tcG9uZW50cyUyRm5vdC1mb3VuZC1ib3VuZGFyeS5qcyZtb2R1bGVzPSUyRlVzZXJzJTJGa2tpaXJ1JTJGRGVza3RvcCUyRmV4cHJlc3MtdHMtYmUtdGVtcGxhdGUlMkZmcm9udGVuZCUyRm5vZGVfbW9kdWxlcyUyRm5leHQlMkZkaXN0JTJGY2xpZW50JTJGY29tcG9uZW50cyUyRnJlbmRlci1mcm9tLXRlbXBsYXRlLWNvbnRleHQuanMmbW9kdWxlcz0lMkZVc2VycyUyRmtraWlydSUyRkRlc2t0b3AlMkZleHByZXNzLXRzLWJlLXRlbXBsYXRlJTJGZnJvbnRlbmQlMkZub2RlX21vZHVsZXMlMkZuZXh0JTJGZGlzdCUyRmNsaWVudCUyRmNvbXBvbmVudHMlMkZzdGF0aWMtZ2VuZXJhdGlvbi1zZWFyY2hwYXJhbXMtYmFpbG91dC1wcm92aWRlci5qcyZzZXJ2ZXI9dHJ1ZSEiLCJtYXBwaW5ncyI6IkFBQUEsa09BQWlKO0FBQ2pKLDBPQUFxSjtBQUNySix3T0FBb0o7QUFDcEosa1BBQXlKO0FBQ3pKLHNRQUFtSztBQUNuSyIsInNvdXJjZXMiOlsid2VicGFjazovL2NoYXQtZnJvbnRlbmQvPzcxM2QiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCIvVXNlcnMva2tpaXJ1L0Rlc2t0b3AvZXhwcmVzcy10cy1iZS10ZW1wbGF0ZS9mcm9udGVuZC9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9jb21wb25lbnRzL2FwcC1yb3V0ZXIuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9Vc2Vycy9ra2lpcnUvRGVza3RvcC9leHByZXNzLXRzLWJlLXRlbXBsYXRlL2Zyb250ZW5kL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L2NvbXBvbmVudHMvZXJyb3ItYm91bmRhcnkuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9Vc2Vycy9ra2lpcnUvRGVza3RvcC9leHByZXNzLXRzLWJlLXRlbXBsYXRlL2Zyb250ZW5kL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L2NvbXBvbmVudHMvbGF5b3V0LXJvdXRlci5qc1wiKTtcbmltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL1VzZXJzL2traWlydS9EZXNrdG9wL2V4cHJlc3MtdHMtYmUtdGVtcGxhdGUvZnJvbnRlbmQvbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9ub3QtZm91bmQtYm91bmRhcnkuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIi9Vc2Vycy9ra2lpcnUvRGVza3RvcC9leHByZXNzLXRzLWJlLXRlbXBsYXRlL2Zyb250ZW5kL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L2NvbXBvbmVudHMvcmVuZGVyLWZyb20tdGVtcGxhdGUtY29udGV4dC5qc1wiKTtcbmltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiL1VzZXJzL2traWlydS9EZXNrdG9wL2V4cHJlc3MtdHMtYmUtdGVtcGxhdGUvZnJvbnRlbmQvbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvY29tcG9uZW50cy9zdGF0aWMtZ2VuZXJhdGlvbi1zZWFyY2hwYXJhbXMtYmFpbG91dC1wcm92aWRlci5qc1wiKSJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fapp-router.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Ferror-boundary.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Flayout-router.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fnot-found-boundary.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Frender-from-template-context.js&modules=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fnode_modules%2Fnext%2Fdist%2Fclient%2Fcomponents%2Fstatic-generation-searchparams-bailout-provider.js&server=true!\n");

/***/ }),

/***/ "(ssr)/./app/page.tsx":
/*!**********************!*\
  !*** ./app/page.tsx ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ChatApp)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ \"(ssr)/./node_modules/axios/lib/axios.js\");\n/* __next_internal_client_entry_do_not_use__ default auto */ \n\n\nconst API_BASE = \"http://localhost:4000/api\";\nconst users = [\n    {\n        id: \"ccc76fd6-ac64-4b00-995c-caab31a90496\",\n        name: \"Alice Johnson\"\n    },\n    {\n        id: \"2d759dd8-05e7-4e0e-bb2b-f87d0e5a5300\",\n        name: \"Bob Smith\"\n    },\n    {\n        id: \"ee07eb77-0b00-4bb0-bfe5-a6837bb3cf1c\",\n        name: \"Charlie Brown\"\n    },\n    {\n        id: \"c47380c0-8579-4273-94de-c9ee0001afc4\",\n        name: \"Diana Prince\"\n    }\n];\nfunction ChatApp() {\n    const [currentUser, setCurrentUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(users[0]);\n    const [messages, setMessages] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);\n    const [newMessage, setNewMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [chatId, setChatId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    // Load chatId from localStorage on component mount\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const savedChatId = localStorage.getItem(\"currentChatId\");\n        if (savedChatId) {\n            setChatId(savedChatId);\n            loadMessages(savedChatId);\n        }\n    }, []);\n    // Save chatId to localStorage whenever it changes\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        if (chatId) {\n            localStorage.setItem(\"currentChatId\", chatId);\n        }\n    }, [\n        chatId\n    ]);\n    const sendMessage = async ()=>{\n        if (!newMessage.trim()) return;\n        setLoading(true);\n        setError(null);\n        try {\n            const payload = {\n                content: newMessage.trim()\n            };\n            // If we have a chatId, use it. Otherwise, create new chat with other users\n            if (chatId) {\n                payload.chatId = chatId;\n            } else {\n                // Include other users as members for new chat\n                payload.memberIds = users.filter((user)=>user.id !== currentUser.id).map((user)=>user.id);\n            }\n            const response = await axios__WEBPACK_IMPORTED_MODULE_2__[\"default\"].post(`${API_BASE}/messages`, payload, {\n                headers: {\n                    \"x-user-id\": currentUser.id,\n                    \"Content-Type\": \"application/json\"\n                }\n            });\n            // Set chatId if this was a new chat\n            if (!chatId && response.data.chatId) {\n                setChatId(response.data.chatId);\n            }\n            setNewMessage(\"\");\n            // Refresh messages\n            if (response.data.chatId) {\n                loadMessages(response.data.chatId);\n            }\n        } catch (err) {\n            setError(err.response?.data?.message || \"Failed to send message\");\n        } finally{\n            setLoading(false);\n        }\n    };\n    const loadMessages = async (chatIdToLoad)=>{\n        try {\n            const response = await axios__WEBPACK_IMPORTED_MODULE_2__[\"default\"].get(`${API_BASE}/messages/${chatIdToLoad}`);\n            setMessages(response.data);\n        } catch (err) {\n            setError(err.response?.data?.message || \"Failed to load messages\");\n        }\n    };\n    const switchUser = (user)=>{\n        setCurrentUser(user);\n    // Don't clear messages and chatId when switching users\n    // This allows users to see the same chat from different perspectives\n    };\n    const startNewChat = ()=>{\n        setMessages([]);\n        setChatId(null);\n        setError(null);\n        localStorage.removeItem(\"currentChatId\");\n    };\n    const handleKeyPress = (e)=>{\n        if (e.key === \"Enter\" && !e.shiftKey) {\n            e.preventDefault();\n            sendMessage();\n        }\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"container\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                style: {\n                    textAlign: \"center\",\n                    marginBottom: \"30px\",\n                    color: \"#374151\"\n                },\n                children: \"Chat Application\"\n            }, void 0, false, {\n                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                lineNumber: 134,\n                columnNumber: 7\n            }, this),\n            error && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"error\",\n                children: error\n            }, void 0, false, {\n                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                lineNumber: 139,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"user-selector\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: \"Select User:\"\n                    }, void 0, false, {\n                        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                        lineNumber: 145,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"user-buttons\",\n                        children: [\n                            users.map((user)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                                    className: `user-button ${currentUser.id === user.id ? \"active\" : \"\"}`,\n                                    onClick: ()=>switchUser(user),\n                                    children: user.name\n                                }, user.id, false, {\n                                    fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                    lineNumber: 148,\n                                    columnNumber: 13\n                                }, this)),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                                className: \"user-button\",\n                                onClick: startNewChat,\n                                style: {\n                                    background: \"#ef4444\",\n                                    color: \"white\",\n                                    border: \"2px solid #ef4444\"\n                                },\n                                children: \"New Chat\"\n                            }, void 0, false, {\n                                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                lineNumber: 156,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                        lineNumber: 146,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                lineNumber: 144,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"chat-container\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"chat-header\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h2\", {\n                                children: [\n                                    \"Chat as \",\n                                    currentUser.name\n                                ]\n                            }, void 0, true, {\n                                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                lineNumber: 168,\n                                columnNumber: 11\n                            }, this),\n                            chatId && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                style: {\n                                    opacity: 0.8,\n                                    fontSize: \"14px\"\n                                },\n                                children: [\n                                    \"Chat ID: \",\n                                    chatId\n                                ]\n                            }, void 0, true, {\n                                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                lineNumber: 169,\n                                columnNumber: 22\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                        lineNumber: 167,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"messages-container\",\n                        children: messages.length === 0 ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"loading\",\n                            children: chatId ? \"No messages yet. Start the conversation!\" : \"Send a message to start a new chat!\"\n                        }, void 0, false, {\n                            fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                            lineNumber: 174,\n                            columnNumber: 13\n                        }, this) : messages.map((message)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                className: `message ${message.sender.id === currentUser.id ? \"sent\" : \"received\"}`,\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                        children: message.content\n                                    }, void 0, false, {\n                                        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                        lineNumber: 183,\n                                        columnNumber: 17\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                        className: \"message-info\",\n                                        children: [\n                                            message.sender.name,\n                                            \" • \",\n                                            new Date(message.createdAt).toLocaleTimeString()\n                                        ]\n                                    }, void 0, true, {\n                                        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                        lineNumber: 184,\n                                        columnNumber: 17\n                                    }, this)\n                                ]\n                            }, message.id, true, {\n                                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                lineNumber: 179,\n                                columnNumber: 15\n                            }, this))\n                    }, void 0, false, {\n                        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                        lineNumber: 172,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"input-container\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                                type: \"text\",\n                                className: \"message-input\",\n                                placeholder: \"Type your message...\",\n                                value: newMessage,\n                                onChange: (e)=>setNewMessage(e.target.value),\n                                onKeyPress: handleKeyPress,\n                                disabled: loading\n                            }, void 0, false, {\n                                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                lineNumber: 193,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                                className: \"send-button\",\n                                onClick: sendMessage,\n                                disabled: loading || !newMessage.trim(),\n                                children: loading ? \"Sending...\" : \"Send\"\n                            }, void 0, false, {\n                                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                                lineNumber: 202,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                        lineNumber: 192,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n                lineNumber: 166,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx\",\n        lineNumber: 133,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9hcHAvcGFnZS50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUUyQztBQUNsQjtBQUV6QixNQUFNRyxXQUFXO0FBb0JqQixNQUFNQyxRQUFnQjtJQUNwQjtRQUFFQyxJQUFJO1FBQXdDQyxNQUFNO0lBQWdCO0lBQ3BFO1FBQUVELElBQUk7UUFBd0NDLE1BQU07SUFBWTtJQUNoRTtRQUFFRCxJQUFJO1FBQXdDQyxNQUFNO0lBQWdCO0lBQ3BFO1FBQUVELElBQUk7UUFBd0NDLE1BQU07SUFBZTtDQUNwRTtBQUVjLFNBQVNDO0lBQ3RCLE1BQU0sQ0FBQ0MsYUFBYUMsZUFBZSxHQUFHVCwrQ0FBUUEsQ0FBT0ksS0FBSyxDQUFDLEVBQUU7SUFDN0QsTUFBTSxDQUFDTSxVQUFVQyxZQUFZLEdBQUdYLCtDQUFRQSxDQUFZLEVBQUU7SUFDdEQsTUFBTSxDQUFDWSxZQUFZQyxjQUFjLEdBQUdiLCtDQUFRQSxDQUFDO0lBQzdDLE1BQU0sQ0FBQ2MsUUFBUUMsVUFBVSxHQUFHZiwrQ0FBUUEsQ0FBZ0I7SUFDcEQsTUFBTSxDQUFDZ0IsU0FBU0MsV0FBVyxHQUFHakIsK0NBQVFBLENBQUM7SUFDdkMsTUFBTSxDQUFDa0IsT0FBT0MsU0FBUyxHQUFHbkIsK0NBQVFBLENBQWdCO0lBRWxELG1EQUFtRDtJQUNuREMsZ0RBQVNBLENBQUM7UUFDUixNQUFNbUIsY0FBY0MsYUFBYUMsT0FBTyxDQUFDO1FBQ3pDLElBQUlGLGFBQWE7WUFDZkwsVUFBVUs7WUFDVkcsYUFBYUg7UUFDZjtJQUNGLEdBQUcsRUFBRTtJQUVMLGtEQUFrRDtJQUNsRG5CLGdEQUFTQSxDQUFDO1FBQ1IsSUFBSWEsUUFBUTtZQUNWTyxhQUFhRyxPQUFPLENBQUMsaUJBQWlCVjtRQUN4QztJQUNGLEdBQUc7UUFBQ0E7S0FBTztJQUVYLE1BQU1XLGNBQWM7UUFDbEIsSUFBSSxDQUFDYixXQUFXYyxJQUFJLElBQUk7UUFFeEJULFdBQVc7UUFDWEUsU0FBUztRQUVULElBQUk7WUFDRixNQUFNUSxVQUFlO2dCQUNuQkMsU0FBU2hCLFdBQVdjLElBQUk7WUFDMUI7WUFFQSwyRUFBMkU7WUFDM0UsSUFBSVosUUFBUTtnQkFDVmEsUUFBUWIsTUFBTSxHQUFHQTtZQUNuQixPQUFPO2dCQUNMLDhDQUE4QztnQkFDOUNhLFFBQVFFLFNBQVMsR0FBR3pCLE1BQ2pCMEIsTUFBTSxDQUFDQyxDQUFBQSxPQUFRQSxLQUFLMUIsRUFBRSxLQUFLRyxZQUFZSCxFQUFFLEVBQ3pDMkIsR0FBRyxDQUFDRCxDQUFBQSxPQUFRQSxLQUFLMUIsRUFBRTtZQUN4QjtZQUVBLE1BQU00QixXQUFXLE1BQU0vQiw2Q0FBS0EsQ0FBQ2dDLElBQUksQ0FBQyxDQUFDLEVBQUUvQixTQUFTLFNBQVMsQ0FBQyxFQUFFd0IsU0FBUztnQkFDakVRLFNBQVM7b0JBQ1AsYUFBYTNCLFlBQVlILEVBQUU7b0JBQzNCLGdCQUFnQjtnQkFDbEI7WUFDRjtZQUVBLG9DQUFvQztZQUNwQyxJQUFJLENBQUNTLFVBQVVtQixTQUFTRyxJQUFJLENBQUN0QixNQUFNLEVBQUU7Z0JBQ25DQyxVQUFVa0IsU0FBU0csSUFBSSxDQUFDdEIsTUFBTTtZQUNoQztZQUVBRCxjQUFjO1lBRWQsbUJBQW1CO1lBQ25CLElBQUlvQixTQUFTRyxJQUFJLENBQUN0QixNQUFNLEVBQUU7Z0JBQ3hCUyxhQUFhVSxTQUFTRyxJQUFJLENBQUN0QixNQUFNO1lBQ25DO1FBQ0YsRUFBRSxPQUFPdUIsS0FBVTtZQUNqQmxCLFNBQVNrQixJQUFJSixRQUFRLEVBQUVHLE1BQU1FLFdBQVc7UUFDMUMsU0FBVTtZQUNSckIsV0FBVztRQUNiO0lBQ0Y7SUFFQSxNQUFNTSxlQUFlLE9BQU9nQjtRQUMxQixJQUFJO1lBQ0YsTUFBTU4sV0FBVyxNQUFNL0IsNkNBQUtBLENBQUNzQyxHQUFHLENBQUMsQ0FBQyxFQUFFckMsU0FBUyxVQUFVLEVBQUVvQyxhQUFhLENBQUM7WUFDdkU1QixZQUFZc0IsU0FBU0csSUFBSTtRQUMzQixFQUFFLE9BQU9DLEtBQVU7WUFDakJsQixTQUFTa0IsSUFBSUosUUFBUSxFQUFFRyxNQUFNRSxXQUFXO1FBQzFDO0lBQ0Y7SUFFQSxNQUFNRyxhQUFhLENBQUNWO1FBQ2xCdEIsZUFBZXNCO0lBQ2YsdURBQXVEO0lBQ3ZELHFFQUFxRTtJQUN2RTtJQUVBLE1BQU1XLGVBQWU7UUFDbkIvQixZQUFZLEVBQUU7UUFDZEksVUFBVTtRQUNWSSxTQUFTO1FBQ1RFLGFBQWFzQixVQUFVLENBQUM7SUFDMUI7SUFFQSxNQUFNQyxpQkFBaUIsQ0FBQ0M7UUFDdEIsSUFBSUEsRUFBRUMsR0FBRyxLQUFLLFdBQVcsQ0FBQ0QsRUFBRUUsUUFBUSxFQUFFO1lBQ3BDRixFQUFFRyxjQUFjO1lBQ2hCdkI7UUFDRjtJQUNGO0lBRUEscUJBQ0UsOERBQUN3QjtRQUFJQyxXQUFVOzswQkFDYiw4REFBQ0M7Z0JBQUdDLE9BQU87b0JBQUVDLFdBQVc7b0JBQVVDLGNBQWM7b0JBQVFDLE9BQU87Z0JBQVU7MEJBQUc7Ozs7OztZQUkzRXJDLHVCQUNDLDhEQUFDK0I7Z0JBQUlDLFdBQVU7MEJBQ1poQzs7Ozs7OzBCQUlMLDhEQUFDK0I7Z0JBQUlDLFdBQVU7O2tDQUNiLDhEQUFDTTtrQ0FBRzs7Ozs7O2tDQUNKLDhEQUFDUDt3QkFBSUMsV0FBVTs7NEJBQ1o5QyxNQUFNNEIsR0FBRyxDQUFDRCxDQUFBQSxxQkFDVCw4REFBQzBCO29DQUVDUCxXQUFXLENBQUMsWUFBWSxFQUFFMUMsWUFBWUgsRUFBRSxLQUFLMEIsS0FBSzFCLEVBQUUsR0FBRyxXQUFXLEdBQUcsQ0FBQztvQ0FDdEVxRCxTQUFTLElBQU1qQixXQUFXVjs4Q0FFekJBLEtBQUt6QixJQUFJO21DQUpMeUIsS0FBSzFCLEVBQUU7Ozs7OzBDQU9oQiw4REFBQ29EO2dDQUNDUCxXQUFVO2dDQUNWUSxTQUFTaEI7Z0NBQ1RVLE9BQU87b0NBQUVPLFlBQVk7b0NBQVdKLE9BQU87b0NBQVNLLFFBQVE7Z0NBQW9COzBDQUM3RTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQU1MLDhEQUFDWDtnQkFBSUMsV0FBVTs7a0NBQ2IsOERBQUNEO3dCQUFJQyxXQUFVOzswQ0FDYiw4REFBQ1c7O29DQUFHO29DQUFTckQsWUFBWUYsSUFBSTs7Ozs7Ozs0QkFDNUJRLHdCQUFVLDhEQUFDZ0Q7Z0NBQUVWLE9BQU87b0NBQUVXLFNBQVM7b0NBQUtDLFVBQVU7Z0NBQU87O29DQUFHO29DQUFVbEQ7Ozs7Ozs7Ozs7Ozs7a0NBR3JFLDhEQUFDbUM7d0JBQUlDLFdBQVU7a0NBQ1p4QyxTQUFTdUQsTUFBTSxLQUFLLGtCQUNuQiw4REFBQ2hCOzRCQUFJQyxXQUFVO3NDQUNacEMsU0FBUyw2Q0FBNkM7Ozs7O21DQUd6REosU0FBU3NCLEdBQUcsQ0FBQ00sQ0FBQUEsd0JBQ1gsOERBQUNXO2dDQUVDQyxXQUFXLENBQUMsUUFBUSxFQUFFWixRQUFRNEIsTUFBTSxDQUFDN0QsRUFBRSxLQUFLRyxZQUFZSCxFQUFFLEdBQUcsU0FBUyxXQUFXLENBQUM7O2tEQUVsRiw4REFBQzRDO2tEQUFLWCxRQUFRVixPQUFPOzs7Ozs7a0RBQ3JCLDhEQUFDcUI7d0NBQUlDLFdBQVU7OzRDQUNaWixRQUFRNEIsTUFBTSxDQUFDNUQsSUFBSTs0Q0FBQzs0Q0FBSSxJQUFJNkQsS0FBSzdCLFFBQVE4QixTQUFTLEVBQUVDLGtCQUFrQjs7Ozs7Ozs7K0JBTHBFL0IsUUFBUWpDLEVBQUU7Ozs7Ozs7Ozs7a0NBWXZCLDhEQUFDNEM7d0JBQUlDLFdBQVU7OzBDQUNiLDhEQUFDb0I7Z0NBQ0NDLE1BQUs7Z0NBQ0xyQixXQUFVO2dDQUNWc0IsYUFBWTtnQ0FDWkMsT0FBTzdEO2dDQUNQOEQsVUFBVSxDQUFDN0IsSUFBTWhDLGNBQWNnQyxFQUFFOEIsTUFBTSxDQUFDRixLQUFLO2dDQUM3Q0csWUFBWWhDO2dDQUNaaUMsVUFBVTdEOzs7Ozs7MENBRVosOERBQUN5QztnQ0FDQ1AsV0FBVTtnQ0FDVlEsU0FBU2pDO2dDQUNUb0QsVUFBVTdELFdBQVcsQ0FBQ0osV0FBV2MsSUFBSTswQ0FFcENWLFVBQVUsZUFBZTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTXRDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2hhdC1mcm9udGVuZC8uL2FwcC9wYWdlLnRzeD83NjAzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2UgY2xpZW50J1xuXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnXG5cbmNvbnN0IEFQSV9CQVNFID0gJ2h0dHA6Ly9sb2NhbGhvc3Q6NDAwMC9hcGknXG5cbmludGVyZmFjZSBVc2VyIHtcbiAgaWQ6IHN0cmluZ1xuICBuYW1lOiBzdHJpbmdcbn1cblxuaW50ZXJmYWNlIE1lc3NhZ2Uge1xuICBpZDogc3RyaW5nXG4gIGNvbnRlbnQ6IHN0cmluZ1xuICBjcmVhdGVkQXQ6IHN0cmluZ1xuICBzZW5kZXI6IFVzZXJcbiAgY2hhdElkOiBzdHJpbmdcbn1cblxuaW50ZXJmYWNlIENoYXQge1xuICBpZDogc3RyaW5nXG4gIGNyZWF0ZWRBdDogc3RyaW5nXG59XG5cbmNvbnN0IHVzZXJzOiBVc2VyW10gPSBbXG4gIHsgaWQ6ICdjY2M3NmZkNi1hYzY0LTRiMDAtOTk1Yy1jYWFiMzFhOTA0OTYnLCBuYW1lOiAnQWxpY2UgSm9obnNvbicgfSxcbiAgeyBpZDogJzJkNzU5ZGQ4LTA1ZTctNGUwZS1iYjJiLWY4N2QwZTVhNTMwMCcsIG5hbWU6ICdCb2IgU21pdGgnIH0sXG4gIHsgaWQ6ICdlZTA3ZWI3Ny0wYjAwLTRiYjAtYmZlNS1hNjgzN2JiM2NmMWMnLCBuYW1lOiAnQ2hhcmxpZSBCcm93bicgfSxcbiAgeyBpZDogJ2M0NzM4MGMwLTg1NzktNDI3My05NGRlLWM5ZWUwMDAxYWZjNCcsIG5hbWU6ICdEaWFuYSBQcmluY2UnIH0sXG5dXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENoYXRBcHAoKSB7XG4gIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGU8VXNlcj4odXNlcnNbMF0pXG4gIGNvbnN0IFttZXNzYWdlcywgc2V0TWVzc2FnZXNdID0gdXNlU3RhdGU8TWVzc2FnZVtdPihbXSlcbiAgY29uc3QgW25ld01lc3NhZ2UsIHNldE5ld01lc3NhZ2VdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtjaGF0SWQsIHNldENoYXRJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxuXG4gIC8vIExvYWQgY2hhdElkIGZyb20gbG9jYWxTdG9yYWdlIG9uIGNvbXBvbmVudCBtb3VudFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHNhdmVkQ2hhdElkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2N1cnJlbnRDaGF0SWQnKVxuICAgIGlmIChzYXZlZENoYXRJZCkge1xuICAgICAgc2V0Q2hhdElkKHNhdmVkQ2hhdElkKVxuICAgICAgbG9hZE1lc3NhZ2VzKHNhdmVkQ2hhdElkKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgLy8gU2F2ZSBjaGF0SWQgdG8gbG9jYWxTdG9yYWdlIHdoZW5ldmVyIGl0IGNoYW5nZXNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoY2hhdElkKSB7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnY3VycmVudENoYXRJZCcsIGNoYXRJZClcbiAgICB9XG4gIH0sIFtjaGF0SWRdKVxuXG4gIGNvbnN0IHNlbmRNZXNzYWdlID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghbmV3TWVzc2FnZS50cmltKCkpIHJldHVyblxuXG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHNldEVycm9yKG51bGwpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcGF5bG9hZDogYW55ID0ge1xuICAgICAgICBjb250ZW50OiBuZXdNZXNzYWdlLnRyaW0oKVxuICAgICAgfVxuXG4gICAgICAvLyBJZiB3ZSBoYXZlIGEgY2hhdElkLCB1c2UgaXQuIE90aGVyd2lzZSwgY3JlYXRlIG5ldyBjaGF0IHdpdGggb3RoZXIgdXNlcnNcbiAgICAgIGlmIChjaGF0SWQpIHtcbiAgICAgICAgcGF5bG9hZC5jaGF0SWQgPSBjaGF0SWRcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEluY2x1ZGUgb3RoZXIgdXNlcnMgYXMgbWVtYmVycyBmb3IgbmV3IGNoYXRcbiAgICAgICAgcGF5bG9hZC5tZW1iZXJJZHMgPSB1c2Vyc1xuICAgICAgICAgIC5maWx0ZXIodXNlciA9PiB1c2VyLmlkICE9PSBjdXJyZW50VXNlci5pZClcbiAgICAgICAgICAubWFwKHVzZXIgPT4gdXNlci5pZClcbiAgICAgIH1cblxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvcy5wb3N0KGAke0FQSV9CQVNFfS9tZXNzYWdlc2AsIHBheWxvYWQsIHtcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICd4LXVzZXItaWQnOiBjdXJyZW50VXNlci5pZCxcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXG4gICAgICAgIH1cbiAgICAgIH0pXG5cbiAgICAgIC8vIFNldCBjaGF0SWQgaWYgdGhpcyB3YXMgYSBuZXcgY2hhdFxuICAgICAgaWYgKCFjaGF0SWQgJiYgcmVzcG9uc2UuZGF0YS5jaGF0SWQpIHtcbiAgICAgICAgc2V0Q2hhdElkKHJlc3BvbnNlLmRhdGEuY2hhdElkKVxuICAgICAgfVxuXG4gICAgICBzZXROZXdNZXNzYWdlKCcnKVxuICAgICAgXG4gICAgICAvLyBSZWZyZXNoIG1lc3NhZ2VzXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YS5jaGF0SWQpIHtcbiAgICAgICAgbG9hZE1lc3NhZ2VzKHJlc3BvbnNlLmRhdGEuY2hhdElkKVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICBzZXRFcnJvcihlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBzZW5kIG1lc3NhZ2UnKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGxvYWRNZXNzYWdlcyA9IGFzeW5jIChjaGF0SWRUb0xvYWQ6IHN0cmluZykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGF4aW9zLmdldChgJHtBUElfQkFTRX0vbWVzc2FnZXMvJHtjaGF0SWRUb0xvYWR9YClcbiAgICAgIHNldE1lc3NhZ2VzKHJlc3BvbnNlLmRhdGEpXG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldEVycm9yKGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGxvYWQgbWVzc2FnZXMnKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHN3aXRjaFVzZXIgPSAodXNlcjogVXNlcikgPT4ge1xuICAgIHNldEN1cnJlbnRVc2VyKHVzZXIpXG4gICAgLy8gRG9uJ3QgY2xlYXIgbWVzc2FnZXMgYW5kIGNoYXRJZCB3aGVuIHN3aXRjaGluZyB1c2Vyc1xuICAgIC8vIFRoaXMgYWxsb3dzIHVzZXJzIHRvIHNlZSB0aGUgc2FtZSBjaGF0IGZyb20gZGlmZmVyZW50IHBlcnNwZWN0aXZlc1xuICB9XG5cbiAgY29uc3Qgc3RhcnROZXdDaGF0ID0gKCkgPT4ge1xuICAgIHNldE1lc3NhZ2VzKFtdKVxuICAgIHNldENoYXRJZChudWxsKVxuICAgIHNldEVycm9yKG51bGwpXG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2N1cnJlbnRDaGF0SWQnKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlS2V5UHJlc3MgPSAoZTogUmVhY3QuS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyAmJiAhZS5zaGlmdEtleSkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICBzZW5kTWVzc2FnZSgpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgPGgxIHN0eWxlPXt7IHRleHRBbGlnbjogJ2NlbnRlcicsIG1hcmdpbkJvdHRvbTogJzMwcHgnLCBjb2xvcjogJyMzNzQxNTEnIH19PlxuICAgICAgICBDaGF0IEFwcGxpY2F0aW9uXG4gICAgICA8L2gxPlxuXG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVycm9yXCI+XG4gICAgICAgICAge2Vycm9yfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidXNlci1zZWxlY3RvclwiPlxuICAgICAgICA8aDM+U2VsZWN0IFVzZXI6PC9oMz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1c2VyLWJ1dHRvbnNcIj5cbiAgICAgICAgICB7dXNlcnMubWFwKHVzZXIgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e3VzZXIuaWR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHVzZXItYnV0dG9uICR7Y3VycmVudFVzZXIuaWQgPT09IHVzZXIuaWQgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN3aXRjaFVzZXIodXNlcil9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt1c2VyLm5hbWV9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1c2VyLWJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtzdGFydE5ld0NoYXR9XG4gICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnI2VmNDQ0NCcsIGNvbG9yOiAnd2hpdGUnLCBib3JkZXI6ICcycHggc29saWQgI2VmNDQ0NCcgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBOZXcgQ2hhdFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoYXQtY29udGFpbmVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hhdC1oZWFkZXJcIj5cbiAgICAgICAgICA8aDI+Q2hhdCBhcyB7Y3VycmVudFVzZXIubmFtZX08L2gyPlxuICAgICAgICAgIHtjaGF0SWQgJiYgPHAgc3R5bGU9e3sgb3BhY2l0eTogMC44LCBmb250U2l6ZTogJzE0cHgnIH19PkNoYXQgSUQ6IHtjaGF0SWR9PC9wPn1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZXNzYWdlcy1jb250YWluZXJcIj5cbiAgICAgICAgICB7bWVzc2FnZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2FkaW5nXCI+XG4gICAgICAgICAgICAgIHtjaGF0SWQgPyAnTm8gbWVzc2FnZXMgeWV0LiBTdGFydCB0aGUgY29udmVyc2F0aW9uIScgOiAnU2VuZCBhIG1lc3NhZ2UgdG8gc3RhcnQgYSBuZXcgY2hhdCEnfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIG1lc3NhZ2VzLm1hcChtZXNzYWdlID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17bWVzc2FnZS5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtZXNzYWdlICR7bWVzc2FnZS5zZW5kZXIuaWQgPT09IGN1cnJlbnRVc2VyLmlkID8gJ3NlbnQnIDogJ3JlY2VpdmVkJ31gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdj57bWVzc2FnZS5jb250ZW50fTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZS1pbmZvXCI+XG4gICAgICAgICAgICAgICAgICB7bWVzc2FnZS5zZW5kZXIubmFtZX0g4oCiIHtuZXcgRGF0ZShtZXNzYWdlLmNyZWF0ZWRBdCkudG9Mb2NhbGVUaW1lU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSlcbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlucHV0LWNvbnRhaW5lclwiPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibWVzc2FnZS1pbnB1dFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlR5cGUgeW91ciBtZXNzYWdlLi4uXCJcbiAgICAgICAgICAgIHZhbHVlPXtuZXdNZXNzYWdlfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdNZXNzYWdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIG9uS2V5UHJlc3M9e2hhbmRsZUtleVByZXNzfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzZW5kLWJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtzZW5kTWVzc2FnZX1cbiAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8ICFuZXdNZXNzYWdlLnRyaW0oKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7bG9hZGluZyA/ICdTZW5kaW5nLi4uJyA6ICdTZW5kJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufSJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImF4aW9zIiwiQVBJX0JBU0UiLCJ1c2VycyIsImlkIiwibmFtZSIsIkNoYXRBcHAiLCJjdXJyZW50VXNlciIsInNldEN1cnJlbnRVc2VyIiwibWVzc2FnZXMiLCJzZXRNZXNzYWdlcyIsIm5ld01lc3NhZ2UiLCJzZXROZXdNZXNzYWdlIiwiY2hhdElkIiwic2V0Q2hhdElkIiwibG9hZGluZyIsInNldExvYWRpbmciLCJlcnJvciIsInNldEVycm9yIiwic2F2ZWRDaGF0SWQiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwibG9hZE1lc3NhZ2VzIiwic2V0SXRlbSIsInNlbmRNZXNzYWdlIiwidHJpbSIsInBheWxvYWQiLCJjb250ZW50IiwibWVtYmVySWRzIiwiZmlsdGVyIiwidXNlciIsIm1hcCIsInJlc3BvbnNlIiwicG9zdCIsImhlYWRlcnMiLCJkYXRhIiwiZXJyIiwibWVzc2FnZSIsImNoYXRJZFRvTG9hZCIsImdldCIsInN3aXRjaFVzZXIiLCJzdGFydE5ld0NoYXQiLCJyZW1vdmVJdGVtIiwiaGFuZGxlS2V5UHJlc3MiLCJlIiwia2V5Iiwic2hpZnRLZXkiLCJwcmV2ZW50RGVmYXVsdCIsImRpdiIsImNsYXNzTmFtZSIsImgxIiwic3R5bGUiLCJ0ZXh0QWxpZ24iLCJtYXJnaW5Cb3R0b20iLCJjb2xvciIsImgzIiwiYnV0dG9uIiwib25DbGljayIsImJhY2tncm91bmQiLCJib3JkZXIiLCJoMiIsInAiLCJvcGFjaXR5IiwiZm9udFNpemUiLCJsZW5ndGgiLCJzZW5kZXIiLCJEYXRlIiwiY3JlYXRlZEF0IiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiaW5wdXQiLCJ0eXBlIiwicGxhY2Vob2xkZXIiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwidGFyZ2V0Iiwib25LZXlQcmVzcyIsImRpc2FibGVkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./app/page.tsx\n");

/***/ }),

/***/ "(rsc)/./app/globals.css":
/*!*************************!*\
  !*** ./app/globals.css ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (\"575a3ce7dab1\");\nif (false) {}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvZ2xvYmFscy5jc3MiLCJtYXBwaW5ncyI6Ijs7OztBQUFBLGlFQUFlLGNBQWM7QUFDN0IsSUFBSSxLQUFVLEVBQUUsRUFBdUIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jaGF0LWZyb250ZW5kLy4vYXBwL2dsb2JhbHMuY3NzPzRmNTgiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgXCI1NzVhM2NlN2RhYjFcIlxuaWYgKG1vZHVsZS5ob3QpIHsgbW9kdWxlLmhvdC5hY2NlcHQoKSB9XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./app/globals.css\n");

/***/ }),

/***/ "(rsc)/./app/layout.tsx":
/*!************************!*\
  !*** ./app/layout.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RootLayout),\n/* harmony export */   metadata: () => (/* binding */ metadata)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals.css */ \"(rsc)/./app/globals.css\");\n\n\nconst metadata = {\n    title: \"Chat App\",\n    description: \"Simple chat application\"\n};\nfunction RootLayout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"html\", {\n        lang: \"en\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n            children: children\n        }, void 0, false, {\n            fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/layout.tsx\",\n            lineNumber: 15,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/layout.tsx\",\n        lineNumber: 14,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvbGF5b3V0LnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBc0I7QUFFZixNQUFNQSxXQUFXO0lBQ3RCQyxPQUFPO0lBQ1BDLGFBQWE7QUFDZixFQUFDO0FBRWMsU0FBU0MsV0FBVyxFQUNqQ0MsUUFBUSxFQUdUO0lBQ0MscUJBQ0UsOERBQUNDO1FBQUtDLE1BQUs7a0JBQ1QsNEVBQUNDO3NCQUFNSDs7Ozs7Ozs7Ozs7QUFHYiIsInNvdXJjZXMiOlsid2VicGFjazovL2NoYXQtZnJvbnRlbmQvLi9hcHAvbGF5b3V0LnRzeD85OTg4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi9nbG9iYWxzLmNzcydcblxuZXhwb3J0IGNvbnN0IG1ldGFkYXRhID0ge1xuICB0aXRsZTogJ0NoYXQgQXBwJyxcbiAgZGVzY3JpcHRpb246ICdTaW1wbGUgY2hhdCBhcHBsaWNhdGlvbicsXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJvb3RMYXlvdXQoe1xuICBjaGlsZHJlbixcbn06IHtcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZVxufSkge1xuICByZXR1cm4gKFxuICAgIDxodG1sIGxhbmc9XCJlblwiPlxuICAgICAgPGJvZHk+e2NoaWxkcmVufTwvYm9keT5cbiAgICA8L2h0bWw+XG4gIClcbn0iXSwibmFtZXMiOlsibWV0YWRhdGEiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiUm9vdExheW91dCIsImNoaWxkcmVuIiwiaHRtbCIsImxhbmciLCJib2R5Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/layout.tsx\n");

/***/ }),

/***/ "(rsc)/./app/page.tsx":
/*!**********************!*\
  !*** ./app/page.tsx ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/kkiiru/Desktop/express-ts-be-template/frontend/app/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/axios","vendor-chunks/asynckit","vendor-chunks/math-intrinsics","vendor-chunks/es-errors","vendor-chunks/@swc","vendor-chunks/call-bind-apply-helpers","vendor-chunks/debug","vendor-chunks/get-proto","vendor-chunks/mime-db","vendor-chunks/has-symbols","vendor-chunks/gopd","vendor-chunks/function-bind","vendor-chunks/form-data","vendor-chunks/follow-redirects","vendor-chunks/supports-color","vendor-chunks/proxy-from-env","vendor-chunks/ms","vendor-chunks/mime-types","vendor-chunks/hasown","vendor-chunks/has-tostringtag","vendor-chunks/has-flag","vendor-chunks/get-intrinsic","vendor-chunks/es-set-tostringtag","vendor-chunks/es-object-atoms","vendor-chunks/es-define-property","vendor-chunks/dunder-proto","vendor-chunks/delayed-stream","vendor-chunks/combined-stream"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fpage&page=%2Fpage&appPaths=%2Fpage&pagePath=private-next-app-dir%2Fpage.tsx&appDir=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fkkiiru%2FDesktop%2Fexpress-ts-be-template%2Ffrontend&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();